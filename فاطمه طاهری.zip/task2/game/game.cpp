#include "skill.h"
#include "charactor.h"
#include "game.h"

#include <iostream>
#include <vector>

game::game(){}

void game::addChara(const chara& chara){
    charas.push_back(chara);
}

void game::remoChara(const std::string& namerem){
    int size=charas.size();
    for(int i=0 ; i < size ; i++ ){
        if(namerem==charas[i].getName()){
            charas.erase(charas.begin() + i );
        }
    }
}

void game::showChara()const{
    for(const auto& chara : charas){
        chara.showChar();
        std::cout<<std::endl;
    }
}