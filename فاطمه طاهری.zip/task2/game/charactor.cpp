#include "charactor.h"
#include "skill.h"

#include <iostream>
#include <vector>


chara::chara(const std::string name , int health , int power):name(name) , health(health) , power(power){ }

std::string chara::getName()const{
    return name;
}

int chara::getHealth()const{
    return health;
}

int chara::getPower()const{
    return power;
}

void chara::setName(std::string newname){
    name=newname;
}

void chara::setHealth(int newhealth){
    health=newhealth;
}

void chara::setPower(int newpower){
    power=newpower;
}

void chara::addSkill(const skill& skill){
    skills.push_back(skill);
}

void chara::delSkill(const std::string& namedel){
    int size=skills.size();
    bool found=false;
    for(int i=0 ; i < size ; i++ ){
        if(namedel==skills[i].getName()){
            skills.erase( skills.begin() + i );//
            found=true;
        }
    }
    if(found==false){
        std::cerr<<"invalid skill "<<namedel<<" for delete."<<std::endl;
    }
}

void chara::showChar()const{
    std::cout<<"Name charactor: "<<name<<std::endl;
    std::cout<<"Health: "<<health<<std::endl;
    std::cout<<"Power: "<<power<<std::endl;
    std::cout<<"Skills: ";
        for(const auto& skill : skills){
            skill.showSkill();
        }
}