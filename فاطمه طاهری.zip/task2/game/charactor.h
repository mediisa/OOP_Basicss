#ifndef CHARACTOR_H
#define CHARACTOR_H

#include "skill.h"

#include <iostream>
#include <vector>

class chara{
    private:
    std::string name;
    int health;
    int power;
    std::vector<skill> skills;

    public:
    chara(std::string name , int health , int power );

    std::string getName()const;
    int getHealth()const;
    int getPower()const;

    void setName(std::string newname);
    void setHealth(int newHealth);
    void setPower(int newPower);

    void addSkill(const skill& skill);
    void delSkill(const std::string& namedel);

    void showChar()const;

};
#endif