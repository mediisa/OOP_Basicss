کامند ها به صورت زیر است
add charactor یزای اضافه کردن کاراکتر ها 
remove charactor حذف کاراکتر ها 
show charactor نمایش کاراکترها 
exit خروج از برنامه