#ifndef GAME_H
#define GAME_H

#include "skill.h"
#include "charactor.h"

#include <iostream>
#include <vector>

class game{
    private:
    std::vector<chara> charas;
    public:
    game();
    void addChara(const chara& chara);
    void remoChara(const std::string& charaName);
    void showChara()const;
};

#endif