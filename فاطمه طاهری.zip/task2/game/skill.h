#ifndef SKILL_H
#define SKILL_H

#include <iostream>

class skill{
    private:
    std::string name;
    int level;

    public:
    
    skill(std::string name , int level);
    std::string getName()const;
    int getLevel()const;
    void setLevel(int newLevel);
    void showSkill()const;
};
#endif