#include "skill.h"
#include "charactor.h"
#include "game.h"

#include <iostream>
#include <string>
#include <algorithm>


std::string to_lowercase(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}

std::string readCommand() {
    std:: string command;
    std::cout << "Enter command: " << std::endl;
    std::getline(std::cin, command);
    std::string lowerCommand = to_lowercase(command);
    return lowerCommand;
}

int main( ){
    game gam;
    int a;

    while(true){
    std::string cmd=readCommand();
    if(cmd=="add charactor" || cmd=="remove charactor" || cmd=="show charactor" || cmd=="exit"){
        if(cmd=="add charactor"){
            std::cout<<"How many charactor do you want to add :";
                std::cin>>a;
                while(a != 0){
                    std::string nam;
                    int health,power,numSkill;
                    std::cout<<"*************************************"<<std::endl;
                    std::cout<<"enter the name of charactor :";
                    std::cin>>nam;
                    std::cout<<"enter health for :";
                    std::cin>>health;
                    std::cout<<"enter power for :";
                    std::cin>>power;
                    chara chara( nam , health , power );


                    std::cout<<"How many skill dose :";
                    std::cin>>numSkill;
                        for(int i=0 ; i < numSkill ; i++ ){
                            std::string skillNam;
                            int level;
                            std::cout<<"enter the skill name :";
                            std::cin>>skillNam;
                            std::cout<<"enter skill level for :";
                            std::cin>>level;
                            skill skil(skillNam , level);
                            chara.addSkill(skil);
                        }

                        gam.addChara(chara);
                    a--;
                }
        }else if(cmd=="remove charactor"){
            std::cout<<"How many charactor do you want to remove :";
            std::cin>>a;
            while(a != 0){
            std::string rem;
            std::cout<<"***********************************"<<std::endl;
            std::cout<<"enter the name of charactor :";
            std::cin>>rem;
            gam.remoChara(rem);
            
            a--;
            }
        }else if(cmd=="show charactor"){
            gam.showChara();
        }else if(cmd=="exit"){
            exit(0);
        }

    }else{
        std::cout<<"Wrong command, enter the command again ."<<std::endl;
    }
    }
}