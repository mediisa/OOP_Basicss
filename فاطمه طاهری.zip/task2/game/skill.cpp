#include "skill.h"

#include <iostream>

//skill::skill(){}
skill::skill(const std::string name , int level) : name(name) , level(level) {} 

std::string skill::getName()const{
    return name;
}

int skill::getLevel()const{
    return level;
}

void skill::setLevel(int newLevel){
    if(newLevel>0){
        level=newLevel;
    }
}

void skill::showSkill()const{
    std::cout<<"Name: "<<name<<std::endl;
    std::cout<<"Level: "<<level<<std::endl;
}