#include "star.h"
#include "sky.h"

#include <iostream>
#include <string>
#include <algorithm>


std::string to_lowercase(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}

std::string readCommand() {
    std:: string command;
    std::cout << "Enter command: " << std::endl;
    std::getline(std::cin, command);
    std::string lowerCommand = to_lowercase(command);
    return lowerCommand;
}

int main(){
    int x,y,light,a;
    std::string cmd;
    sky nightsky;
    while(true){
        std::string cmd = readCommand();
        if (cmd=="add star" || cmd=="show star" || cmd=="exit"){
            if(cmd=="add star"){
                std::cout<<"How many stars do you want to add : ";
                std::cin>>a;
                while(a != 0 ){
                    std::cout<<"Enter the X : ";
                    std::cin>>x;
                    std::cout<<"Enter the Y : ";
                    std::cin>>y;   
                    std::cout<<"Enter the light : ";
                    std::cin>>light; 
                        try{
                            star starr(x,y,light);
                            nightsky.addStar(starr);
                        }catch(const std::invalid_argument& e){
                            std::cerr << "Error: " << e.what() << std::endl;
                        }
                    
                    a--;
                }
            }else if (cmd=="show star"){
                nightsky.show();
            }else if (cmd=="exit"){
                exit(0);
            }
        }else{
            std::cout<<"Wrong command, enter the command again ."<<std::endl;
        }
    }
}