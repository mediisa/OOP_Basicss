#include "star.h"
#include "sky.h"

#include <iostream>

sky::sky() {}

void sky::addStar(const star& star){
    stars.push_back(star);
}

void sky::show(){
    int wight=100;
    int hight=100;

    char sky[hight][wight];//ساخت فضای اسمون 

    for(int i=0 ; i < hight ; i++ ){
        for(int j=0 ; j < wight ; j++ ){
            sky[i][j]=' ';
        }
    }

    for(const auto& star : stars){
        if(star.getX() < wight && star.getY() < hight ){
            sky[star.getX()][star.getY()]='*';
        }
    }

    for(int i=0 ; i < hight ; i++ ){
        for(int j=0 ; j < wight ; j++ ){
            std::cout<<sky[i][j];
        }
        std::cout<<std::endl;
    }
    

}