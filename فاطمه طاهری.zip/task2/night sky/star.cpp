#include "star.h"

#include <iostream>
#include <string>
#include <algorithm>

star::star(int x , int y , int light ): x(x) , y(y) ,light(light) {
    if(( x<0 || x>=100 ) && ( y<0 || y>=100 )){
        throw std::invalid_argument("Invalid X and Y. X and Y must be between 0 and 99 .");
    }

    if( x<0 || x>=100 ){
        throw std::invalid_argument("Invalid X. X must be between 0 and 99 .");
    }

    if( y<0 || y>=100 ){
        throw std::invalid_argument("Invalid Y. Y must be between 0 and 99 .");
    }
}

star::star(){}

int star::getX()const{
    return x;
}

int star::getY()const{
    return y;
}

int star::getLight()const{
    return light;
}

void star::setX(int newx){
    x=newx;
}

void star::setY(int newy){
    y=newy;
}

void star::setLight(int newLight){
    light=newLight;
}