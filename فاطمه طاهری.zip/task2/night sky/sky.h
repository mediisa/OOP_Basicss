#ifndef SKY_H
#define SKY_H

#include "star.h"

#include <iostream>
#include <vector>


class sky{
    private:
        std::vector<star> stars;
    public:
    sky();
    void addStar(const star& star);
    void show();

    //void render();
};
#endif