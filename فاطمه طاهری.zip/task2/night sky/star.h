#ifndef STAR_H
#define STAR_H

#include <iostream>
#include <string>

class star{
    private:
    int x;
    int y;
    int light;

    public:
    star(int x, int y, int light);
    star();

    int getX()const;
    int getY()const;
    int getLight()const;

    void setX(int newx);
    void setY(int newy);
    void setLight(int newLight);

};
#endif