کامند ها به صورت زیر
برای اضافه کردن رویداد add eventcalendar
برای بروزرسانی رویداد ها refresh eventcalendar
نشان دادن تمام رویداد ها show all eventcalendar
برای خروج exit

