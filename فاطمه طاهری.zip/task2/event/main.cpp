#include "calendar.h"
#include "event.h"

#include <iostream>
#include <string>
#include <ctime>
#include <vector>
#include <fstream>
#include <iomanip>
#include <algorithm>

std::string to_lowercase(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}

std::string readCommand() {
    std::string command;
    std::cout << "Enter command: " << std::endl;
    std::getline(std::cin, command);
    std::string lowerCommand = to_lowercase(command);
    return lowerCommand;
}

void perform(std::string& cmd, cal& cale) {
    if (cmd == "add eventcalendar") {
        int startMonth, startDay, startHour, startMin, startSec;
        int endMonth, endDay, endHour, endMin, endSec;
        std::string name, com;
        bool found = false;
        int a;

        std::cout << "How many events do you want to add: " << std::endl;
        std::cin >> a;
        while (a != 0) {
            std::cout << "Enter Event Name: " << std::endl;
            std::cin >> com;
            std::getline(std::cin, com);
            name = to_lowercase(com);
            do {
                std::cout << "Enter start month (1-12): ";
                std::cin >> startMonth;
                std::cout << "Enter start day (1-31): ";
                std::cin >> startDay;
                std::cout << "Enter start hour (0-23): ";
                std::cin >> startHour;
                std::cout << "Enter start minute (0-59): ";
                std::cin >> startMin;
                std::cout << "Enter start second (0-59): ";
                std::cin >> startSec;

                std::cout << "Enter end month (1-12): ";
                std::cin >> endMonth;
                std::cout << "Enter end day (1-31): ";
                std::cin >> endDay;
                std::cout << "Enter end hour (0-23): ";
                std::cin >> endHour;
                std::cout << "Enter end minute (0-59): ";
                std::cin >> endMin;
                std::cout << "Enter end second (0-59): ";
                std::cin >> endSec;

                try {
                    Event newEvent(name, startMonth, startDay, startHour, startMin, startSec,
                                   endMonth, endDay, endHour, endMin, endSec);
                    cale.add(newEvent);
                    found = true;
                } catch (const std::invalid_argument& e) {
                    std::cerr << e.what() << std::endl;
                    std::cout << "Please enter the valid values again." << std::endl;
                }
            } while (!found);
            a--;
        }
    } else if (cmd == "refresh eventcalendar") {
        cale.refresh();
    } else if (cmd == "show all eventcalendar") {
        cale.show();
    } else if (cmd == "exit") {
        exit(0);
    }
}

int main() {
    cal cale;
    while (true) {
        std::string cmd = readCommand();
        if (cmd == "show all eventcalendar" || cmd == "refresh eventcalendar" || cmd == "add eventcalendar" || cmd == "exit") {
            if (cmd == "add eventcalendar") {
                int startMonth, startDay, startHour, startMin, startSec;
                int endMonth, endDay, endHour, endMin, endSec;
                std::string com;
                bool found = false;
                int a;
        
                std::cout << "How many events do you want to add: " << std::endl;
                std::cin >> a;
                while (a != 0) {
                    std::cout << "Enter Event Name: " << std::endl;
                    std::cin >> com;
                    //std::getline(std::cin, com);
                    ///std::string lowerCommand = to_lowercase(com);
                    //std::cout<<"++++"<<lowerCommand<<std::endl;
                    do {
                        std::cout << "Enter start month (1-12): ";
                        std::cin >> startMonth;
                        std::cout << "Enter start day (1-31): ";
                        std::cin >> startDay;
                        std::cout << "Enter start hour (0-23): ";
                        std::cin >> startHour;
                        std::cout << "Enter start minute (0-59): ";
                        std::cin >> startMin;
                        std::cout << "Enter start second (0-59): ";
                        std::cin >> startSec;
        
                        std::cout << "Enter end month (1-12): ";
                        std::cin >> endMonth;
                        std::cout << "Enter end day (1-31): ";
                        std::cin >> endDay;
                        std::cout << "Enter end hour (0-23): ";
                        std::cin >> endHour;
                        std::cout << "Enter end minute (0-59): ";
                        std::cin >> endMin;
                        std::cout << "Enter end second (0-59): ";
                        std::cin >> endSec;
        
                        try {
                            Event newEvent(com , startMonth, startDay, startHour, startMin, startSec,
                                           endMonth, endDay, endHour, endMin, endSec);
                            cale.add(newEvent);
                            found = true;
                        } catch (const std::invalid_argument& e) {
                            std::cerr << e.what() << std::endl;
                            std::cout << "Please enter the valid values again." << std::endl;
                        }
                    } while (!found);
                    a--;
                }
            } else if (cmd == "refresh eventcalendar") {
                cale.refresh();
            } else if (cmd == "show all eventcalendar") {
                cale.show();
            } else if (cmd == "exit"){
                exit(0);
            }
        } else {
            std::cout << "Wrong command, enter the command again." << std::endl;
        }
    }
    return 0;
}
