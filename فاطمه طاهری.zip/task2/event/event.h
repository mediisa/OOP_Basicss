#ifndef EVENT_H
#define EVENT_H

#include <iostream>
#include <string>

struct DateTime {
    int month;
    int day;
    int hour;
    int min;
    int sec;
};

class Event {
private:
    std::string name;
    DateTime startTime;
    DateTime endTime;

public:
    Event(const std::string& name, int startMonth, int startDay, int startHour, int startMin, int startSec,
          int endMonth, int endDay, int endHour, int endMin, int endSec);
    Event();

    std::string getName() const;

    DateTime getStartTime() const;
    DateTime getEndTime() const;

    void setName(const std::string& newName);
    void setStartTime(int month, int day, int hour, int min, int sec);
    void setEndTime(int month, int day, int hour, int min, int sec);

    void showEvent() const;

    bool isValidDate(int month, int day) const;
    bool isValidTime(int hour, int min, int sec) const;

    ~Event();
};

#endif
