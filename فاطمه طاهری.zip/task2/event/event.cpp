#include "event.h"

#include <iostream>
#include <string>
#include <ctime>

Event::Event(const std::string& name, int startMonth, int startDay, int startHour, int startMin, int startSec,
             int endMonth, int endDay, int endHour, int endMin, int endSec) : name(name) {
    if (isValidDate(startMonth, startDay) && isValidTime(startHour, startMin, startSec) &&
        isValidDate(endMonth, endDay) && isValidTime(endHour, endMin, endSec)) {
        startTime = {startMonth, startDay, startHour, startMin, startSec};
        endTime = {endMonth, endDay, endHour, endMin, endSec};
    } else {
        throw std::invalid_argument("Invalid date or time");
    }
}

Event::Event() {}

std::string Event::getName() const {
    return name;
}

DateTime Event::getStartTime() const {
    return startTime;
}

DateTime Event::getEndTime() const {
    return endTime;
}

void Event::setName(const std::string& newName) {
    name = newName;
}

void Event::setStartTime(int month, int day, int hour, int min, int sec) {
    if (isValidDate(month, day) && isValidTime(hour, min, sec)) {
        startTime = {month, day, hour, min, sec};
    }
}

void Event::setEndTime(int month, int day, int hour, int min, int sec) {
    if (isValidDate(month, day) && isValidTime(hour, min, sec)) {
        endTime = {month, day, hour, min, sec};
    }
}

void Event::showEvent() const {
    std::cout << "Event name: " << name << std::endl;
    std::cout << "Start Date: " << startTime.day << " / " << startTime.month << " / 2025" << std::endl;
    std::cout << "Start Time: " << startTime.hour << ":" << startTime.min << ":" << startTime.sec << std::endl;
    std::cout << "End Date: " << endTime.day << " / " << endTime.month << " / 2025" << std::endl;
    std::cout << "End Time: " << endTime.hour << ":" << endTime.min << ":" << endTime.sec << std::endl;
}

bool Event::isValidDate(int month, int day) const {
    if (month < 1 || month > 12) {
        return false;
    }
    if (day < 1 || day > 31) {
        return false;
    }
    if (month == 2 && day <= 29) {
        return true;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
        return (day <= 30);
    }
    return true;
}

bool Event::isValidTime(int hour, int min, int sec) const {
    return (hour >= 0 && hour < 24) && (min >= 0 && min < 60) && (sec >= 0 && sec < 60);
}

Event::~Event() {
    std::cout << "Event " << name << " is being deleted." << std::endl;
}
