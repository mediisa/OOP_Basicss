#ifndef CALENDAR_H
#define CALENDAR_H

#include "event.h"
#include <vector>

class cal {
private:
    std::vector<Event> events;

public:
    cal();
    void add(const Event& newEvent);
    void refresh();
    void show();
    ~cal();

    bool check(const Event& newEvent) const;
};

#endif
