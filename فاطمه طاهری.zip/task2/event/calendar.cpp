#include "calendar.h"
#include "event.h"

#include <iostream>
#include <string>
#include <ctime>
#include <vector>
#include <fstream>
#include <iomanip>

cal::cal() {}

void cal::add(const Event& newEvent) {
    if (check(newEvent)) {
        std::cerr << "Event " << newEvent.getName() << " conflicts with another event." << std::endl;
        return;
    }

    events.push_back(newEvent);

    //std::fstream file("Event.txt", std::ios::out | std::ios::in | std::ios::app);
    //if (!file) {
    //  std::cerr << "Error opening file!" << std::endl;
    //} else {
    //    file << "Event name " << std::setw(10) << "Start Date " << std::setw(15) << "Start Time "
    //         << std::setw(15) << "End Date " << std::setw(15) << "End Time " << std::endl;
    //    file << newEvent.getName() << " "
    //         << newEvent.getStartTime().day << " / " << newEvent.getStartTime().month << " / 2025 &"
    //         << newEvent.getStartTime().hour << ":" << newEvent.getStartTime().min << ":" << newEvent.getStartTime().sec << " "
    //         << newEvent.getEndTime().day << " / " << newEvent.getEndTime().month << " / 2025 &"
    //         << newEvent.getEndTime().hour << ":" << newEvent.getEndTime().min << ":" << newEvent.getEndTime().sec << "." << std::endl;
    //}
}

void cal::refresh() {
    time_t now = time(0);
    tm* ltm = localtime(&now);
    int Mon = ltm->tm_mon + 1;
    int Day = ltm->tm_mday;
    int Hour = ltm->tm_hour;
    int Min = ltm->tm_min;
    int Sec = ltm->tm_sec;

    for (auto it = events.begin(); it != events.end();) {
        DateTime endTime = it->getEndTime();
        if (endTime.month < Mon ||
            (endTime.month == Mon && endTime.day < Day) ||
            (endTime.month == Mon && endTime.day == Day && endTime.hour < Hour) ||
            (endTime.month == Mon && endTime.day == Day && endTime.hour == Hour && endTime.min < Min) ||
            (endTime.month == Mon && endTime.day == Day && endTime.hour == Hour && endTime.min == Min && endTime.sec < Sec)) {

            std::cout << "Event '" << it->getName() << "' has expired and will be removed." << std::endl;
            it = events.erase(it);
        } else {
            ++it;
        }
    }

    /*std::fstream file("Event.txt", std::ios::out | std::ios::trunc);
    if (!file) {
        std::cerr << "Error opening file!" << std::endl;
    }

    file << "Event name " << std::setw(10) << "Start Date " << std::setw(15) << "Start Time "
         << std::setw(15) << "End Date " << std::setw(15) << "End Time " << std::endl;
    for (const auto& event : events) {
        file << event.getName() << " "
             << event.getStartTime().day << " / " << event.getStartTime().month << " / 2025 &"
             << event.getStartTime().hour << ":" << event.getStartTime().min << ":" << event.getStartTime().sec << " "
             << event.getEndTime().day << " / " << event.getEndTime().month << " / 2025 &"
             << event.getEndTime().hour << ":" << event.getEndTime().min << ":" << event.getEndTime().sec << "." << std::endl;
    }*/
}

void cal::show() {
    for (const auto& event : events) {
        event.showEvent();
    }
}

cal::~cal() {
    events.clear();
}

bool cal::check(const Event& newEvent) const {
    for (const auto& existing : events) {
        //چک کردن تایم برای افزودن رویداد جدید
        if (newEvent.getStartTime().month == existing.getStartTime().month &&
            newEvent.getStartTime().day == existing.getStartTime().day &&
            newEvent.getStartTime().hour == existing.getStartTime().hour) {
            return true;
        }
    }
    return false;
}
