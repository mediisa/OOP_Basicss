#include "gps.h"

#include <iostream>
#include <string>
#include <stdexcept>

location::location(double lat , double lon ): x(lat), y(lon){
    if ( (lat < -90.00 || lat > 90.00) && (lon < -180.00 || lon > 180.00) ){
         throw std::invalid_argument("Invalid latitude and longitude. Latitude must be between -90 and 90 Longitude must be between -180 and 180.");
    }

    if ( lat < -90.00 || lat > 90.00 ){
        throw std::invalid_argument("Invalid latitude. Latitude must be between -90 and 90.");
    }

    if( lon < -180.00 || lon > 180.00 ){
        throw std::invalid_argument("Invalid longitude. Longitude must be between -180 and 180.");
    }


}

location::~location(){

}

double location::getX() const {
    return x;
}

double location::getY() const {
    return y;
}

double location::setX(double newX){
    x=newX;
    return x;
}

double location::setY(double newY){
    y=newY;
    return y;
}