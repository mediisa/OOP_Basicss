#ifndef GPS_H
#define GPS_H

#include <iostream>
#include <string>
#include <stdexcept>

class location{
    private:
    double x;
    double y;

    public:
    location(double lat , double lon);
    ~location();

    double getX() const;
    double getY() const;

    double setX(double newX);
    double setY(double newY);
};
#endif