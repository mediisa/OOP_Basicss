#include "gps.h"
#include <iostream>
#include <ctime>
#include <fstream>

void log(int x , int y){
    time_t now = time(0);
    tm* ltm = localtime(&now);
    int Mon = ltm->tm_mon + 1;
    int Day = ltm->tm_mday;
    int Hour = ltm->tm_hour;
    int Min = ltm->tm_min;
    int Sec = ltm->tm_sec;

    std::fstream fileLog("log.txt" , std::ios::in | std::ios::out | std::ios::app );

    if(fileLog.is_open()){
        fileLog<<Day<<"/"<<Mon<<"/2025     "<<Hour<<":"<<Min<<":"<<Sec<<"    GPS Location: Latitude = "<<x<<" Longitude = "<<y<< std::endl;
    }else{
        std::cerr<<"file not open! ";
    }
    
}
int main(){
    double x,y;
    std::cout<<"Enter the longitude : "<<std::endl;
    std::cin>>x;
    std::cout<<"Enter the latitude  : "<<std::endl;
    std::cin>>y;

    try { // نمایش مقادیر معتبر
        location loc(x,y);
       
        std::cout << "Valid GPS Location: Latitude = " << loc.getX() << " Longitude = " << loc.getY() << std::endl;
            log(x,y);
    }catch (const std::invalid_argument& e) { // نمایش خطا در صورت ورودی نامعتبر
        std::cerr << "Error: " << e.what() << std::endl;
    }
}