#include "hospital.h"
#include "patint.h"

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>

hospital::hospital( ){
  //  readd();
}

hospital::~hospital(){
 //   save();//قبل تخریب سیو میکنم
}

void hospital::add(const patint& patint) {//اضافه کردن بیمار

    for(const auto& overPatint : patints){
        if(overPatint.getName()==patint.getName()){
            std::cout<<"Patint with the name "<<patint.getName()<<" already exists . "<<std::endl;
        }
    }

    patints.push_back(patint);
    save(patint);//بیمار جدید رو سیو میکنه
}

std::string hospital::codefun(const std::string& text){
    std::string res=text;
    for(size_t i=0 ; i < text.length() ; i++ ){
        res[i]=text[i] ^ 'A';//از عملوند XOR
    }
    return res;
}

void hospital::save(const patint& patient){//سیو کردن 
    std::fstream file("hospital.txt" , std::ios::in | std::ios::out | std::ios::app );

    if(file.is_open()){

        file<<patient.getCodeName()<<" "<<patient.getCodeAge()<<" "<<patient.getCodeTem()
        <<" "<<patient.getCodeHeart()<<" "<<patient.getCodeRES()<<" "<<patient.getCodeBlood()
        <<"  "<<std::endl;
  
        file.close();
    }else{
        std::cerr<<"open the file . ";
    }
}

void hospital::readd() {

    std::ifstream file("hospital.txt");
    std::string line;

    if (file.is_open()) {
        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string name;
            int Age;
            float Temperature;
            int heartRate;
            int Respiratory;
            int Blood;
            std::string temp;

            std::getline(ss, name, ',');
            std::getline(ss, temp, ',');
            Age = std::stof(temp);
            std::getline(ss, temp, ',');
            Temperature = std::stof(temp);
            std::getline(ss, temp, ',');
            heartRate = std::stoi(temp);
            std::getline(ss, temp, ',');
            Respiratory = std::stoi(temp);
            std::getline(ss, temp, ',');
            Blood = std::stoi(temp);

            patint patint(name , Age , Temperature , heartRate , Respiratory , Blood);
            patints.push_back(patint);
        }
    
        file.close();
    }else{
        std::cerr<<"file not open! "<<std::endl;
    }
    
}

void hospital::showAll(){//نمایش دادن  
    
    std::cout << "List of patients :" << std::endl<<std::endl;
    std::ifstream file("hospital.txt");
    std::string line;

    /*if(file.is_open()){
        std::vector<std::string> data;

        while(std::getline(file , line)){
            std::stringstream ss(line);
            std::string token;
            
                while(std::getline(ss, token ,' ')){
                    if(!token.empty()){
                        data.push_back(token);
                    }
                }
        }
       for(const auto& str : data){
        std::string dacrypted = codefun(str);
        std::cout<<dacrypted;
        std::cout<<std::endl;
        }
    
}*/
   if (file.is_open()) {
     
        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string Name , name , age , tem , he , RES , blo ;
            int Age;
            float Temperature;
            int heartRate;
            int Respiratory;
            int Blood;
            std::string temp;
            std::getline(ss, name, ' ');
            Name = codefun(name);
            std::getline(ss, temp, ' ');
            age = codefun(temp);
            //Age = std::stoi(age);
            std::getline(ss, temp, ' ');
            tem = codefun(temp);
            //Temperature = std::stof(tem);
            std::getline(ss, temp, ' ');
            he = codefun(temp);
            //heartRate = std::stoi(he);
            std::getline(ss, temp, ' ');
            RES = codefun(temp);
            //Respiratory = std::stoi(RES);
            std::getline(ss, temp, ' ');
            blo = codefun(temp);
            //Blood = std::stoi(blo);

            std::cout<<"Name : "<<Name <<std::endl
            <<"Age : "<<age <<std::endl
            <<"body Temperature : "<<tem<<std::endl
            <<"Heartbeat : "<<he<<std::endl
            <<"Respiratory : "<<RES<<std::endl
            <<"Blood Pressure : "<<blo<<std::endl;
        }
    
        file.close();
    }else{
        std::cerr<<"file not open! "<<std::endl;
    }
   /*//// std::cout << "List of patients :" << std::endl<<std::endl;
    std::ifstream file("hospital.txt");
    std::string line;

    if(file.is_open()){
        while(getline(file , line) ){
            std::cout<<line<<std::endl;
        }
        file.close();
    }else{
        std::cerr<<"file not open!!";
    }*////
    /*  if (patints.empty()) {
        std::cout << "No patients in the hospital." << std::endl;
        return;
    }
        
    for (const auto& patient : patints) {
        patient.showPatint();
        std::cout << "--------------------" << std::endl;
    }*/
}