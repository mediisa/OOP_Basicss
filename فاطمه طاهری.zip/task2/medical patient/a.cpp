#include <iostream>

std::string codefun(const std::string& text){
    std::string res=text;
    for(size_t i=0 ; i < text.length() ; i++ ){
        res[i]=text[i] ^ 'A';//از عملوند XOR
    }
    return res;
}

int main(){
std::string f=codefun("#-..%a13$2243$a{a");
std::cout<<f;
}