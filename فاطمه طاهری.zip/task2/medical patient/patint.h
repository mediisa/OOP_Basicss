#ifndef PATINT_H
#define PATINT_H

#include <iostream>
#include <string>

class patint{
    private:
    std::string name;
    int age;
    float temperature;//دمای بدن
    int heart;//ضربان قلب 
    int respiratory;//تعداد تنفس
    int blood;//فشار خون
    std::string codeName;//اسم رمز
    std::string codeAge;
    std::string codeTem;
    std::string codeHeart;
    std::string codeRES;
    std::string codeBlood;
    const char codeKey='A';//کلید رمز

   
    
    public:
    patint(const std::string& name , int& age , float& temperature , int& heart , int& raspiratory , int& blood);
    ~patint();
    
    std::string funcCode(const std::string& text);//تابع کدگذاری
    std:: string getName() const;
    int getAge() const;
    float getTemperature() const;
    int getHeart() const;
    int getRespiratory() const;
    int getBlood() const;
    std::string getCodeName()const;
    std::string getCodeAge()const;
    std::string getCodeTem()const;
    std::string getCodeHeart()const;
    std::string getCodeRES()const;
    std::string getCodeBlood()const;


    void setTemperature(float newTem);
    void setHeart(int newHeart);
    void setRespiratory(int newRes);
    void setBlood(int newBlood);

    void showPatint() const;
    void check(int age);

};
#endif