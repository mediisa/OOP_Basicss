#include "patint.h"

#include <iostream>
#include <fstream>
#include <string>


std::string patint::funcCode(const std::string& text){
    std::string res=text;
    for(size_t i=0 ; i < text.length() ; i++ ){
        res[i]=text[i] ^ codeKey;//از عملوند XOR
    }
    return res;
}
 

patint::patint(const std::string& name , int& age , float& temperature , int& heart , int& respiratory , int& blood)
        :name(name) , age(age) , temperature(temperature) , heart(heart) , respiratory(respiratory) , blood(blood) {

            check(age);
            codeName=funcCode(name);
            std::string agee=std::to_string(age);
            codeAge=funcCode(agee);
            std::string tem=std::to_string(temperature);
            codeTem=funcCode(tem);
            std::string he=std::to_string(heart);
            codeHeart=funcCode(he);
            std::string re=std::to_string(respiratory);
            codeRES=funcCode(re);
            std::string blo=std::to_string(blood);
            codeBlood=funcCode(blo);
}

patint::~patint(){
    std::cout<<"Decrypting patient data ... "<<std::endl;
    //std::string decrytedName=funcCode(codeName);
    //std::cout<<"CodeName : "<<codeName<<std::endl;
    std::cout<<"orginal name : "<<name<<std::endl;
    std::cout<<"orginal age : "<<age<<std::endl;
    std::cout<<"orginal body Temperature : "<<temperature<<std::endl;
    std::cout<<"orginal Heartbeat : "<<heart<<std::endl;
    std::cout<<"orginal Respiratory : "<<respiratory<<std::endl;
    std::cout<<"orginal Blood Pressure : "<<blood<<std::endl; 
}

std::string patint::getName()const{
    return name;
}

int patint::getAge()const{
    return age;
}

float patint::getTemperature()const{
    return temperature;
}

int patint::getHeart()const{
    return heart;
}

int patint::getRespiratory()const{
    return respiratory;
}

int patint::getBlood()const{
    return blood;
}

std::string patint::getCodeName()const{
    return codeName;
}

std::string patint::getCodeAge()const{
    return codeAge;
}

std::string patint::getCodeTem()const{
    return codeTem;
}

std::string patint::getCodeHeart()const{
    return codeHeart;
}

std::string patint::getCodeRES()const{
    return codeRES;
}

std::string patint::getCodeBlood()const{
    return codeBlood;
}


void patint::setTemperature(float newTem){
    if(newTem < 30.00 || newTem > 41.00 ){
        std::cout<<"invalid body temperature ."<<std::endl;
    }

    temperature=newTem;
}

void patint::setHeart(int newHeart){
    if(newHeart < 0 || newHeart > 200 ){
        std::cout<<"invalid heartbeat ."<<std::endl;
    }

    heart=newHeart;
}

void patint::setRespiratory(int newRes){
    if(newRes < 0 || newRes > 50 ){
        std::cout<<"invalid respiratory rate ."<<std::endl;
    }

    respiratory=newRes;
}

void patint::setBlood(int newBlood){
    if(newBlood < 0 || newBlood > 200 ){
        std::cout<<"invalid blood pressure ."<<std::endl;
    }

    blood=newBlood;
}


void patint::showPatint()const{
    std::cout<<"Name : "<<name<<std::endl;
    std::cout<<"Age : "<<age<<std::endl;
    std::cout<<"body Tempeeature : "<<temperature<<std::endl;
    std::cout<<"Heartbeat : "<<heart<<std::endl;
    std::cout<<"Respiratory : "<<respiratory<<std::endl;
    std::cout<<"Blood Pressure : "<<blood<<std::endl;   
}

void patint::check(int age){//چک کردن که در صورت غیرطبیعی بودن هشدار بده
    if(age >= 18 ){
        if(temperature < 36.00 || temperature >37.50 ){
            std::cout<<"Alert: "<<name<<" has abnormal Temperature!!"<<std::endl;
        }
        if(heart < 60 || heart > 100 ){
            std::cout<<"Alert: "<<name<<" has abnormal Heartbeat!!"<<std::endl;    
        }
        if(respiratory < 16 || respiratory > 20 ){
            std::cout<<"Alert: "<<name<<" has abnormal Respiratory rate!!"<<std::endl; 
        }
        if(blood < 80 || blood > 120 ){
            std::cout<<"Alert: "<<name<<" has abnormal Blood Pressure!!"<<std::endl; 
        }


    }else if(age < 12 ){
        if(temperature < 36.00 || temperature >37.50 ){
            std::cout<<"Alert: "<<name<<" has abnormal Temperature!!"<<std::endl;
        }
        if(heart < 70 || heart > 110 ){
            std::cout<<"Alert: "<<name<<" has abnormal Heartbeat!!"<<std::endl;    
        }
        if(respiratory < 20 || respiratory > 30 ){
            std::cout<<"Alert: "<<name<<" has abnormal Respiratory rate!!"<<std::endl; 
        }
        if(blood < 70 || blood > 110 ){
            std::cout<<"Alert: "<<name<<" has abnormal Blood Pressure!!"<<std::endl; 
        }

    }else{
        if(temperature < 36.00 || temperature >37.50 ){
            std::cout<<"Alert: "<<name<<" has abnormal Temperature!!"<<std::endl;
        }
        if(heart < 60 || heart > 100 ){
            std::cout<<"Alert: "<<name<<" has abnormal Heartbeat!!"<<std::endl;    
        }
        if(respiratory < 16 || respiratory > 25 ){
            std::cout<<"Alert: "<<name<<" has abnormal Respiratory rate!!"<<std::endl; 
        }
        if(blood < 70 || blood > 120 ){
            std::cout<<"Alert: "<<name<<" has abnormal Blood Pressure!!"<<std::endl; 
        }
    }
}

/*void patint::savefile(){ 
    std::fstream File(ho)
}*/