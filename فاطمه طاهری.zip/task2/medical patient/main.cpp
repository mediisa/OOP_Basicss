#include "hospital.h"
#include "patint.h"

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>


std::string to_lowercase(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}

std::string readCommand() {
    std:: string command;
    std::cout << "Enter command: " << std::endl;
    std::getline(std::cin, command);
    std::string lowerCommand = to_lowercase(command);
    return lowerCommand;
}

/*void func(std::string cmd , hospital& hos){
    if(cmd=="add patient"){
        std::string name , com ;
        int age , heart , resp , blood , a ;
        float tem;

        std::cout<<"How many patient do you want to add :"<<std::endl;
        std::cin>>a;
        while(a != 0 ){
            std::cout << "Enter the patient's name: " << std::endl;
            std::cin>>com;
            std::getline(std::cin, com);
            name= to_lowercase(com);
            std::cout << "Enter the age: " << std::endl;
            std::cin>>age;
            std::cout << "Enter the body Tempeeature: " << std::endl;
            std::cin>>tem;
            std::cout << "Enter the Heartbeat: " << std::endl;
            std::cin>>heart;
            std::cout << "Enter the Respiratory: " << std::endl;
            std::cin>>resp;   
            std::cout << "Enter the Blood Pressure: " << std::endl;
            std::cin>>blood;

            patint newpatint(name , age , tem , heart , resp , blood );
            try {
                patint newpatint(name , age , tem , heart , resp , blood );    
                hos.add(newpatint); 
            } catch (const std::invalid_argument& e) {
                std::cerr << e.what() << std::endl;
            }
            a--;
        }
    }else if(cmd=="show all patient"){
        hos.showAll();
    }else if (cmd=="exit"){
        exit(0);
    }
}*/

int main(){
    hospital hos;
    //patint newpatint;
    std::string cmd;
    while(true){
        std::string cmd = readCommand();
        if(cmd=="show all patient" || cmd=="add patient" || cmd=="exit"){
            if(cmd=="add patient"){
                std::string name , com ;
                int age , heart , resp , blood , a ;
                float tem;
        
                std::cout<<"How many patient do you want to add :"<<std::endl;
                std::cin>>a;
                while(a != 0 ){
                    std::cout << "Enter the patient's name: " << std::endl;
                    std::cin>>com;
                    //std::getline(std::cin, com);
                    //name= to_lowercase(com);
                    std::cout << "Enter the age: " << std::endl;
                    std::cin>>age;
                    std::cout << "Enter the body Temperature: " << std::endl;
                    std::cin>>tem;
                    std::cout << "Enter the Heartbeat: " << std::endl;
                    std::cin>>heart;
                    std::cout << "Enter the Respiratory: " << std::endl;
                    std::cin>>resp;   
                    std::cout << "Enter the Blood Pressure: " << std::endl;
                    std::cin>>blood;
        
                    //patint newpatint(name , age , tem , heart , resp , blood );
                    try {
                        patint newpatint(com , age , tem , heart , resp , blood );    
                        hos.add(newpatint); 
                    } catch (const std::invalid_argument& e) {
                        std::cerr << e.what() << std::endl;
                    }
                    a--;
                }
            }else if(cmd=="show all patient"){
                hos.showAll();
            }else if (cmd=="exit"){
                exit(0);
            }
        }else{
            std::cout<<"Wrong command, enter the command again ."<<std::endl;
        }
    }
}