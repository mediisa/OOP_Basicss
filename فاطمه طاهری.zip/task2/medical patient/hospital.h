#ifndef HOSPITAL_H
#define HOSPITAL_H

#include "patint.h"

#include <iostream>
#include <string>
#include <vector>
#include <fstream>

class hospital{
    private:
    std::vector<patint> patints;

    public:
    hospital();
    ~hospital();

    std::string codefun(const std::string& text);
    void add(const patint& patint);
    void showAll();
    void readd();
    void save(const patint& patient);

};

#endif